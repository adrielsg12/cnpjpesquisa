<?php
class TestService
{
    public function test($param)
    {
        var_dump($param);
    }
}
