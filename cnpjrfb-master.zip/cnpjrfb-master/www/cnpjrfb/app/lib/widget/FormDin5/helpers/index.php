<?php
/**
 * FormDin or Dynamic Form is a php Framework for creating web system quickly and easily.
 *
 * @author  Bjverde <bjverde@yahoo.com.br>
 * @license https://github.com/bjverde/formDin/blob/master/LICENSE GPL-3.0
 * @link    https://github.com/bjverde/formDin
 *
 * PHP Version 7.0
 */

header('Location: ../index.php');